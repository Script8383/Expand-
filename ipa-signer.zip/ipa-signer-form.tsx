"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function IPASignerForm() {
  const [files, setFiles] = useState({
    ipa: null,
    mobileProvision: null,
    p12: null,
  })
  const [password, setPassword] = useState("")

  const handleFileChange = (field: string, e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      setFiles((prev) => ({
        ...prev,
        [field]: e.target.files?.[0],
      }))
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission here
    console.log("Files:", files)
    console.log("Password:", password)
  }

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-md mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-center">ANARCHISM Signer</h1>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="ipa" className="text-lg flex items-center">
              IPA <span className="text-red-500 ml-1">*</span>
            </Label>
            <div className="grid grid-cols-2 gap-2">
              <Button
                type="button"
                variant="secondary"
                className="bg-[#1c1c2a] hover:bg-[#2a2a3a] text-gray-300"
                onClick={() => document.getElementById("ipa")?.click()}
              >
                Choose File
              </Button>
              <div className="bg-[#1c1c2a] rounded-md px-4 py-2 text-gray-400">
                {files.ipa?.name || "no file selected"}
              </div>
            </div>
            <Input id="ipa" type="file" accept=".ipa" className="hidden" onChange={(e) => handleFileChange("ipa", e)} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="mobileprovision" className="text-lg flex items-center">
              MobileProvision <span className="text-red-500 ml-1">*</span>
            </Label>
            <div className="grid grid-cols-2 gap-2">
              <Button
                type="button"
                variant="secondary"
                className="bg-[#1c1c2a] hover:bg-[#2a2a3a] text-gray-300"
                onClick={() => document.getElementById("mobileprovision")?.click()}
              >
                Choose File
              </Button>
              <div className="bg-[#1c1c2a] rounded-md px-4 py-2 text-gray-400">
                {files.mobileProvision?.name || "no file selected"}
              </div>
            </div>
            <Input
              id="mobileprovision"
              type="file"
              accept=".mobileprovision"
              className="hidden"
              onChange={(e) => handleFileChange("mobileProvision", e)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="p12" className="text-lg flex items-center">
              P12 <span className="text-red-500 ml-1">*</span>
            </Label>
            <div className="grid grid-cols-2 gap-2">
              <Button
                type="button"
                variant="secondary"
                className="bg-[#1c1c2a] hover:bg-[#2a2a3a] text-gray-300"
                onClick={() => document.getElementById("p12")?.click()}
              >
                Choose File
              </Button>
              <div className="bg-[#1c1c2a] rounded-md px-4 py-2 text-gray-400">
                {files.p12?.name || "no file selected"}
              </div>
            </div>
            <Input id="p12" type="file" accept=".p12" className="hidden" onChange={(e) => handleFileChange("p12", e)} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="text-lg">
              Password
            </Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-[#1c1c2a] border-0 text-white"
            />
          </div>

          <Button type="submit" className="w-full bg-blue-500 hover:bg-blue-600 text-white text-xl py-6">
            Upload and Sign
          </Button>
        </form>
      </div>
    </div>
  )
}

