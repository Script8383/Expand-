"use client"

import IPASignerForm from "../ipa-signer-form"

export default function SyntheticV0PageForDeployment() {
  return <IPASignerForm />
}